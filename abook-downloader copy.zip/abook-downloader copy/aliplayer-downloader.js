let Browser = require("zombie"), fs = require("fs");
let promisify = function (f, self, args) {
	return new Promise(function (resolve, reject) {
		for (let i = 0; i < args.length; i++) {
			if (args[i] === promisify.callback) {
				args[i] = function () {
					resolve(arguments);
				};
			}
		}
		try {
			f.apply(self, args);
		} catch (exception) {
			reject(exception);
		}
	});
};
promisify.callback = Symbol("Promisify Callback");
module.exports = (async function () {
	let browser = new Browser();
	let callback = [];
	await promisify(browser.visit, browser, ["about:blank", promisify.callback]);
	browser.window["onbdfjbnvogwrgu4bsbl"] = function () {
		let stack = new Error().stack;
		return stack.slice(stack.indexOf("zvnrjeorgls") + "zvnrjeorgls".length, stack.indexOf("fjdbneorno"));
	};
	browser.window["ihnoewufuvfskjn"] = function (o) {
		throw "oiwnhgfdovslntoewweofn" + o;
	};
	browser.window["wobfeuavhsdsijlg"] = function (func) {
		setTimeout(func);
	};
	browser.window["gfhfowvnsoerogbn"] = function (result, id = browser.window["ihnoewufuvfskjn"]) {
		let cb = callback[id];
		clearTimeout(cb[2]);
		callback[id] = undefined;
		delete callback[id];
		if (typeof (result) === "string" && result.slice(0, 22) === "oiwnhgfdovslntoewweofn") {
			cb[0](result.slice(22));
		} else {
			cb[1](result);
		}
	};
	browser.evaluate(`(function () {
		window.doksnvoiernbo = eval;
		window.eval = function () {};
		let origSetTimeout = window.setTimeout;
		let origCreateElement = document.createElement;
		document.createElement = function () {
			if (arguments[0] == "script") {
				arguments[0] = "script-disabled";
				let ret = origCreateElement.apply(this, arguments);
				let id = window["onbdfjbnvogwrgu4bsbl"]();
				wobfeuavhsdsijlg(function () {
					try {
						doksnvoiernbo("(function zvnrjeorgls" + id + "fjdbneorno (func, self, args) { func.apply(self, args); })")(ret.onload, ret, []);
					} catch (exception) {
						window["gfhfowvnsoerogbn"](exception, id);
					}
				});
				return ret;
			} else {
				return origCreateElement.apply(this, arguments);
			}
		};
		let origCreateElementNS = document.createElementNS;
		document.createElementNS = function () {
			if (arguments[0] == "script") {
				arguments[0] = "script-disabled";
				let ret = origCreateElementNS.apply(this, arguments);
				wobfeuavhsdsijlg(function () {
					ret.onload();
				});
				return ret;
			} else {
				return origCreateElementNS.apply(this, arguments);
			}
		};
		window.setTimeout = function () {};
		window.setInterval = function () {};
	})();`);
	browser.evaluate(fs.readFileSync("aliplayer-2.8.7.js").toString()
		.replaceAll('.aliyuncs.com/?"+r;n.get(o,function(e){if(e){var', '.aliyuncs.com/?"+r;window["ihnoewufuvfskjn"](o);n.get(o,function(e){if(e){var ')
		.replaceAll('new Function', "new String"));
	return function (videoId, playAuth, timeout=10 * 1000) {
		return new Promise(function (resolve, reject) {
			let id = "A" + Math.floor(Math.random() * 10000000000);
			let timeoutTimeoutId = setTimeout(function () {
				callback[id] = undefined;
				delete callback[id];
				reject(new Error("timeout"));
			}, timeout);
			callback[id] = [resolve, reject, timeoutTimeoutId];
			try {
				browser.evaluate(`(function () {
					let playerContainer = document.createElement("div");
					playerContainer.id="playerContainer";
					document.body.append(playerContainer);
					(function zvnrjeorgls` + id + `fjdbneorno () {
						new Aliplayer({
							"vid": "` + videoId + `",
							"playauth": "` + playAuth + `",
							"id": "playerContainer",
							"mediaType": "video",
							"playsinline": true,
							"preload": true,
							"useH5Prism": true,
							"defaultDefinition":"OD",
						});
					})();
				})();`);
			} catch (exception) {
				browser.window["gfhfowvnsoerogbn"](exception, id);
			}
		});
	};
})();
module.exports.promisify = promisify;