let request = require("request");
let fs = require("fs");
let readline = require("readline");
let crypto = require("crypto");
let util = require("util");
(async function () {
	getAliplayerPlayInfo = await require("./aliplayer-downloader");
	let promisify = function (f, self, args) {
		args = Array.from(args);
		return new Promise(function (resolve, reject) {
			let existCallback = false;
			for (let i = 0; i < args.length; i++) {
				if (args[i] === promisify.callback) {
					existCallback = true;
					args[i] = function () {
						resolve(arguments);
					};
				}
			}
			if (!existCallback) {
				args.push(function () {
					resolve(arguments);
				});
			}
			try {
				f.apply(self, args);
			} catch (exception) {
				reject(exception);
			}
		});
	};
	let getVideoURL = module.exports.getVideoURL = async function getVideoURL(resourceInfoId) {
		let response1 = JSON.parse((await promisify(request, null, ["https://abook.hep.com.cn/OpenAPIURL.action?resourceInfoId=" + resourceInfoId]))[2]);
		let response2 = JSON.parse((await promisify(request, null, [response1.URL]))[2]);
		return JSON.parse((await promisify(request, null, [await getAliplayerPlayInfo(response1.VideoId, response2.PlayAuth)]))[2]);
	};
	let _session = request.defaults({
		jar: request.jar(),
		forever: true
	});
	let session = async function () {
		let result = await promisify(_session, this, arguments);
		if (result[0]) {
			throw (result[0]);
		}
		if (result[1].statusCode >= 400) {
			let error = new Error("HTTP(S) request error " + result[1].statusCode + ": " + result[1].statusMessage);
			error.statusMessage = result[1].statusMessage;
			error.statusCode = result[1].statusCode;
			error.response = result[1];
			error.body = result[2];
			throw (error);
		}
		return result[2];
	}
	let input = function (prompt) {
		process.stdout.write(prompt);
		return new Promise(function (resolve) {
			let interface = readline.createInterface({
				input: process.stdin
			});
			interface.on("line", function (str) {
				interface.close();
				resolve(str);
			});
		});
	};
	let range = function range(start = 0, stop, step = 1) {
		if (arguments.length == 1) {
			stop = start;
			start = 0;
		}
		return {
			[Symbol.iterator]() {
				let current = start;
				return {
					next: function () {
						let ret;
						if (current < stop) {
							ret = {
								value: current,
								done: false
							}
						} else {
							ret = {
								value: undefined,
								done: true
							}
						}
						current += step;
						return ret;
					}
				};
			}
		};
	};
	let len = function (n) {
		return n.length;
	};
	let print = console.log;
	let sleep = function (n) {
		return new Promise(function (resolve) {
			setTimeout(resolve, 1000 * n);
		});
	};
	let int = function (n) {
		if (isNaN(n)) {
			throw (new Error(n + " is not a number."));
		}
		return Number(n);
	};
	String.prototype.format = function () {
		let args = Array.from(arguments);
		args.unshift(this.replaceAll("{}", "%s"));
		return util.format.apply(util, args);
	};
	String.prototype.find = String.prototype.indexOf;
	String.prototype.rfind = String.prototype.lastIndexOf;
	Array.prototype.append = Array.prototype.push;
	let True = true;
	let False = false;
	let str = String;
	let logging = console;
	let COURSES_INFO_FILE = "./temp/course_info.json"
	let SETTINGS_INFO = "./temp/settings.json"
	let USER_INFO = "./temp/user_info.json"
	let DOWNLOAD_DIR = "./Downloads/"
	let ROOT = 0
	let courses_list = []
	let chapter_list = []
	let settings = []
	let current_user = ["", ""]
	let safe_mkdir = function (dir_name) {
		try {
			fs.mkdirSync(str(dir_name))
		} catch (exception) {}
	}
	let safe_remove = function (dir_name) {
		try {
			fs.rmSync(str(dir_name))
		} catch (exception) {}
	}
	let validate_file_name = function (file_name) {
		file_name = file_name.trim()
		let key_word = ["/／", ':：', '*﹡', '?？', '"”', '<﹤', '>﹤', "|∣"]
		for (i of range(len(key_word))) {
			file_name = file_name.replaceAll(key_word[i][0], key_word[i][1])
		}
		//		/╱／∕		|∣		\＼		*✱✲✳✽﹡		<﹤〈＜‹		>﹥〉＞›
		return file_name
	}
	let load_settings = function (file_name) {
		try {
			settings = JSON.parse(fs.readFileSync(file_name).toString())
		} catch (exception) {
			settings = {'download_path': './Downloads/'}
			save_settings(file_name)
		}
		DOWNLOAD_DIR = settings['download_path']
	}
	let save_settings = function (file_name) {
		fs.writeFileSync(file_name, JSON.stringify(settings, null, "    "))
		logging.info("Settings saved.")
		console.trace()
	}
	let change_download_path = async function () {
		let new_download_path = await input("Input new downloader path: ")
		new_download_path += "/"
		logging.info(new_download_path)
		DOWNLOAD_DIR = new_download_path
		settings['download_path'] = DOWNLOAD_DIR
		save_settings(SETTINGS_INFO)
	}
	let init = function () {
		/*
		This function will create temp and Downloads folders and display welcome.
		temp is for logs and information gathered while the program is running.
		The Downloads folder is where to save the downloaded file by default.
		*/
		safe_mkdir("temp")
		safe_mkdir("Downloads")
		logging.info("Started successfully!")
		load_settings(SETTINGS_INFO)
		print("ABookDownloader是由HEIGE-PCloud编写的开源Abook下载软件")
		print("当前版本 v2.0-beta.2 可前往项目主页检查更新")
		print("项目主页 https://github.com/HEIGE-PCloud/ABookDownloader")
		print("如果遇到任何问题，欢迎提交issue")
		print("如果这款软件帮到了您，欢迎前往该项目主页请作者喝奶茶QwQ")
		print("<========================================================>")
	}
	let file_downloader = function (file_name, url) {
		console.log(file_name, url);
		/*
		headers = {'Proxy-Connection': 'keep-alive'}
		r = session.get(url, stream=True, headers=headers)
		content_length = float(r.headers['content-length'])
		with open(file_name, 'wb') as file {
			downloaded_length = 0
			last_downloaded_length = 0
			time_start = time.time()
			for (let chunk of r.iter_content(chunk_size=512)) {
				if (chunk) {
					file.write(chunk)
					downloaded_length += len(chunk)
					if (time.time() - time_start > 1) {
						percentage = downloaded_length / content_length * 100
						speed = (downloaded_length -
								 last_downloaded_length) / 2097152
						last_downloaded_length = downloaded_length
						print("\r Downloading: " + file_name + ': ' + '{:.2f}'.format(percentage) + '% Speed: ' + '{:.2f}'.format(speed) + 'MB/S', end="")
						time_start = time.time()
					}
				}
			}
		}
		print("\nDownload {} successfully!".format(file_name))
		*/
	}
	let Abook_login = async function (login_name, login_password) {
		let login_url = "https://abook.hep.com.cn/loginMobile.action"
		// login_status_url = "https://abook.hep.com.cn/verifyLoginMobile.action"
		let plainPassword = login_password
		let md5Password = crypto.createHash("md5").end(plainPassword).digest().toString("hex")
		let login_data = {
			'device': 'iPhone',
			'loginUser.loginName': login_name,
			'loginUser.loginPassword': md5Password,
			'packageId': 'com.hep.abook',
			'passType': 'MD5',
			'version': 'v1.170'
		}
		let kvlogin_data = "";
		for (let i in login_data) {
			kvlogin_data += "&" + encodeURIComponent(i) + "=" + encodeURIComponent(login_data[i]);
		}
		kvlogin_data = kvlogin_data.slice(1);
		let headers = {
			"User-Agent": "iPhone",
			"Content-Type": "application/x-www-form-urlencoded",
			"Content-Length": kvlogin_data.length
		}
		let response = JSON.parse(await session(login_url, { body: kvlogin_data, headers: headers, method: "post" }))
		if (response[0]["message"] == "successful") {
			logging.info("Successfully login in!")
			current_user[0] = login_name
			current_user[1] = login_password
			return True
		} else {
			logging.error(response[0]["message"])
			safe_remove("./temp/user_info.json")
			return False
		}
	}
	let get_courses_info = async function (file_name) {
		// Get courses info from login, need  through the path to save the json file of courses information.
		let course_info_url = "https://abook.hep.com.cn/selectMyCourseList.action?mobile=true&cur=1"
		fs.writeFileSync(file_name, JSON.stringify(JSON.parse(await session(course_info_url)), null, "    "))
		logging.info("Courses info fetched!")
	}
	let load_courses_info = function (file_name) {
		// Load courses info from file_name and store them into the global courses_list.
		courses_list = []
		let courses_data;
		try {
			courses_data = JSON.parse(fs.readFileSync(file_name).toString())[0]['myMobileCourseList']
		} catch (exception) {
			logging.error("Cannot load courses.")
			return
		}
		print('There are {} course(s) available.'.format(len(courses_data)))
		for (let course of courses_data) {
			course['courseTitle'] = validate_file_name(course['courseTitle'])
			courses_list.append(course)
		}
		logging.info("Courses info loaded.")
	}
	let get_chapter_info = async function (course_id) {
		// Get the chapter info by course_id
		let course_url = 'https://abook.hep.com.cn/resourceStructure.action?courseInfoId={}'.format(course_id)
		fs.writeFileSync("./temp/" + str(course_id) + '.json', JSON.stringify(JSON.parse(await session(course_url, { method: "post" })), null, "    "))
		logging.info("Chapter for course {} fetched".format(course_id))
	}
	let load_chapter_info = function (course_id) {
		// Load chapter info from local file and store it into globe variable chapter_list.
		chapter_list = []
		let chapter_data = JSON.parse(fs.readFileSync("./temp/" + str(course_id) + '.json').toString())
		for (let chapter of chapter_data) {
			chapter['name'] = validate_file_name(chapter['name'])
			chapter_list.append(chapter)
		}
		logging.info("Chapter for {} loaded.".format(course_id))
	}
	let display_courses_info = function () {
		print("0 下载全部")
		for (let i of range(len(courses_list))) {
			print(i + 1, courses_list[i]['courseTitle'])
		}
		print("o 打开下载文件夹")
		print("s 更改保存目录")
		print("q 退出")
	}
	let display_chapter_info = function (title_name, pid) {
		// Display chapter info by selected course and parrent id.
		print("> " + title_name + ":")
		print("0 下载全部")
		for (let i of range(len(chapter_list))) {
			if (chapter_list[i]['pId'] == pid) {
				print(i + 1, chapter_list[i]['name'])
			}
		}
		print("q 返回上一级")
	}
	let chapter_has_child = function (selected_chapter) {
		let child_chapter = []
		for (let chapter of chapter_list) {
			if (chapter['pId'] == selected_chapter['id']) {
				child_chapter.append(chapter)
			}
		}
		return child_chapter
	}
	let download_course_from_root = async function (root_chapter, course_id, path) {
		// for chapter in root_chapter:
		let child_list = chapter_has_child(root_chapter)
		if (len(child_list) != 0) {
			for (let child of child_list) {
				safe_mkdir(path + child['name'])
				await download_course_from_root(child, course_id, path + child['name'] + '/')
			}
		} else {
			let cur = 1
			let all_page_downloaded = False
			while (all_page_downloaded === False) {
				let download_link_url = "https://abook.hep.com.cn/courseResourceList.action?courseInfoId={}&treeId={}&cur={}"
									.format(course_id, root_chapter['id'], cur)
				let download_url_base = "https://abook.hep.com.cn/ICourseFiles/"
				let download_link_url2 = "https://abook.hep.com.cn/selectResource.action?roleMenuId={}"
									.format(root_chapter['id'])
				let info
				while (True) {
					try {
						info = JSON.parse(await session(download_link_url))[0]
						break
					} catch (exception) {
						logging.error("Info fetched failed, will restart in 5 seconds.")
						await Abook_login(current_user[0], current_user[1])
						await sleep(5)
					}
				}
				print(info, download_link_url)
				let page = info['page']
				let page_count = page["pageCount"]
				if (cur >= page_count) {
					all_page_downloaded = True
				}
				cur += 1
				if ('myMobileResourceList' in info) {
					let course = info['myMobileResourceList']
					print(len(course), "downloadable items found!")
					for (let i of range(len(course))) {
						let file_name = course[i]['resTitle']
						let file_url = course[i]['resFileUrl']
						print(file_name)
						let url = download_url_base + file_url
						file_type = file_url.slice(str(file_url).find('.'))
						if (course[i]['mediaTypeName'] == '视频') {
							// video_page = session.get("http://127.0.0.1:1234/5000313983" + str(course[i]['resourceInfoId'])).json()  TODO
							print(video_page)
							return
							downloadurl_index = video_page.index('title="下载" class="info_a" style="margin-left: 20px;">下载</a>')
							url = video_page.slice(downloadurl_index - 164, downloadurl_index - 7)
							file_type = url.slice(url.rfind('.'))
						}
						print(url)
						let location = path + str(file_name) + str(file_type)
						while (True) {
							try {
								file_downloader(location, url)
								break
							} catch (exception) {
								logging.error("Download failed, will restart in 5 seconds.")
								await sleep(5)
							}
						}
					}
				}
			}
		}
	}
	let download_course = async function (download_dir, selected_course, selected_root) {
		safe_mkdir(download_dir + selected_course['courseTitle'])
		safe_mkdir(download_dir +
				   selected_course['courseTitle'] + "/" + selected_root['name'])
		await download_course_from_root(selected_root, selected_course['courseInfoId'], DOWNLOAD_DIR +
								  selected_course['courseTitle'] + "/" + selected_root['name'] + "/")
	}
	let read_login_info = function (file_name) {
		/*
		Read the local login info from file.  through the file name.
		Return user_info as json if succeed, or return boolean False if failed.
		*/
		try {
			{
				let file = fs.readFileSync(file_name).toString()
				try {
					let login_info = JSON.parse(file)
					logging.info("Successfully read the local user info.")
					return login_info
				} catch (exception) {
					return False
				}
			}
		} catch (exception) {
			logging.info("Did not find local user info. Ask for input instead.")
			return False
		}
	}
	let write_login_info = function (user_info, file_name) {
		// Write the user_info as json to file_name file.
		fs.writeFileSync(file_name, JSON.stringify(user_info, null, "    "))
		logging.info("Login details saved.")
	}
	let select_chapter = async function (title_name, pid) {
		while (True) {
			display_chapter_info(title_name, pid)
			let choice = await input("Enter the chapter index to choose: ")
			if (str(choice) == '0') {
				return True
			}
			if (!isNaN(choice)) {
				choice = int(choice)
				let selected_chapter = chapter_list[choice - 1]
				let result = await select_chapter(selected_chapter['name'], selected_chapter['id'])
				if (result === False) {
					continue
				} else if (result === True) {
					return selected_chapter
				} else {
					return result
				}
			}
			if (str(choice) == 'q') {
				return False
			}
		}
	}
	if (1) {
		init()
		// First check if there is user information stored locally.
		// If there is, then ask whether the user will use it or not.
		// If there isn't, ask user type in information directly.
		let user_info = read_login_info(USER_INFO)
		if (user_info !== False) {
			let choice = await input("User {} founded! Do you want to log in as {}? (y/n) ".format(user_info['loginUser.loginName'], user_info['loginUser.loginName']))
			if (choice == 'n') {
				user_info = False
			}
		}
		if (user_info === False) {
			let login_name = await input("Please input login name: ")
			let login_word = await input("Please input login word: ")
			user_info = {'loginUser.loginName': login_name,
						 'loginUser.loginword': login_word}
			write_login_info(user_info, USER_INFO)
		}
		// User login
		while (True) {
			if (await Abook_login(user_info['loginUser.loginName'], user_info['loginUser.loginword'])) {
				break
			}
			let login_name = await input("Please input login name: ")
			let login_word = await input("Please input login word: ")
			user_info = {'loginUser.loginName': login_name,
						 'loginUser.loginword': login_word}
			write_login_info(user_info, USER_INFO)
		}
		// Get and load courses infomation
		await get_courses_info(COURSES_INFO_FILE)
		load_courses_info(COURSES_INFO_FILE)
		while (True) {
			display_courses_info()
			let choice = await input("Enter course index to choose: ")
			try {
				choice = int(choice)
			} catch (exception) {
				if (choice == 'o') {
					// os.system("explorer " + DOWNLOAD_DIR.replace('/', '\\'))  TODO
					continue
				} else if (choice == 's') {
					await change_download_path()
					continue
				} else {
					logging.info("Bye~")
				}
				break
			}
			// Download All!
			if (choice == 0) {
				for (let selected_course of courses_list) {
					await get_chapter_info(selected_course['courseInfoId'])
					load_chapter_info(selected_course['courseInfoId'])
					let root_list = []
					for (let chapter of chapter_list) {
						if (chapter['pId'] == 0) {
							root_list.append(chapter)
						}
					}
					for (let chapter of root_list) {
						await download_course(DOWNLOAD_DIR, selected_course, chapter)
					}
				}
			} else {
				let selected_course;
				try {
					selected_course = courses_list[choice - 1]
				} catch (exception) {
					print("Wrong Index!")
					continue
				}
				// Get and load chapter information
				await get_chapter_info(selected_course['courseInfoId'])
				load_chapter_info(selected_course['courseInfoId'])
				// select_chapter(selected_course['courseTitle'], ROOT)
				// selected_root
				//			   = True when user choose to download the entire course
				//			   = course_info when user choose to download a specific sub-chapter
				let selected_root = await select_chapter(selected_course['courseTitle'], ROOT)
				if (selected_root === False) {
					continue
				}
				if (selected_root === True) {
					let root_list = []
					for (let chapter of chapter_list) {
						if (chapter['pId'] == 0) {
							root_list.append(chapter)
						}
					}
					for (let chapter of root_list) {
						await download_course(DOWNLOAD_DIR, selected_course, chapter)
					}
				} else {
					await download_course(DOWNLOAD_DIR, selected_course, selected_root)
				}
			}
		}
	}
})();
