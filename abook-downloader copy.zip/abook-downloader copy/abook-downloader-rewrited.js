"use strict";
let request = require("request");
let fs = require("fs");
let readline = require("readline");
let crypto = require("crypto");
let util = require("util");
(async function () {
	let getAliplayerPlayInfo = await require("./aliplayer-downloader");
	let promisify = function (f, self, args) {
		args = Array.from(args);
		return new Promise(function (resolve, reject) {
			let existCallback = false;
			for (let i = 0; i < args.length; i++) {
				if (args[i] === promisify.callback) {
					existCallback = true;
					args[i] = function () {
						resolve(arguments);
					};
				}
			}
			if (!existCallback) {
				args.push(function () {
					resolve(arguments);
				});
			}
			try {
				f.apply(self, args);
			} catch (exception) {
				reject(exception);
			}
		});
	};
	let getVideoURL = module.exports.getVideoURL = async function getVideoURL(resourceInfoId) {
		let response1 = JSON.parse((await promisify(request, null, ["https://abook.hep.com.cn/OpenAPIURL.action?resourceInfoId=" + resourceInfoId]))[2]);
		let response2 = JSON.parse((await promisify(request, null, [response1.URL]))[2]);
		return JSON.parse((await promisify(request, null, [await getAliplayerPlayInfo(response1.VideoId, response2.PlayAuth)]))[2]);
	};
	let input = function (prompt) {
		process.stdout.write(prompt);
		return new Promise(function (resolve) {
			let rlInterface = readline.createInterface({
				input: process.stdin
			});
			rlInterface.on("line", function (str) {
				rlInterface.close();
				resolve(str);
			});
		});
	};
	let range = function range(start = 0, stop, step = 1) {
		if (arguments.length == 1) {
			stop = start;
			start = 0;
		}
		return {
			[Symbol.iterator]() {
				let current = start;
				return {
					next: function () {
						let ret;
						if (current < stop) {
							ret = {
								value: current,
								done: false
							}
						} else {
							ret = {
								value: undefined,
								done: true
							}
						}
						current += step;
						return ret;
					}
				};
			}
		};
	};
	let len = function (n) {
		return n.length;
	};
	let print = function (...args) {
		let temp;
		for (let i in args) {
			temp = args[i];
			if (temp instanceof Buffer) {
				let binary = false;
				for (let i of temp) {
					if (i > 127) {
						binary = true;
						break;
					}
				}
				if (binary) {
					temp = temp.toString("hex");
				} else {
					temp = temp.toString();
				}
				temp = "Buffer[" + temp + "]"
			}
			if (typeof (temp) === "string" || typeof (temp) === "number" || (temp instanceof Number) || (temp instanceof String)) {
				temp = temp.toString();
			} else {
				try {
					temp = JSON.stringify(temp, null, "    ");
				} catch (e) {
					// temp = temp.toString();
				}
			}
			args[i] = temp;
		}
		console.log.apply(console, args);
	};
	let sleep = function (n) {
		return new Promise(function (resolve) {
			setTimeout(resolve, n);
		});
	};
	String.prototype.format = function (...args) {
		args.unshift(String(this));
		return util.format.apply(util, args);
	};
	let validate_file_name = function (file_name) {
		file_name = file_name.trim();
		let key_word = ["/／", ':：', '*﹡', '?？', '"”', '<﹤', '>﹤', "|∣"];
		for (let i of range(len(key_word))) {
			file_name = file_name.replaceAll(key_word[i][0], key_word[i][1]);
		}
		//		/╱／∕		|∣		\＼		*✱✲✳✽﹡		<﹤〈＜‹		>﹥〉＞›
		return file_name;
	};
	let safeMkdir = function (filename) {
		try {
			fs.mkdirSync(validate_file_name(filename))
		} catch (e) {}
	}
	let safeRemove = function (filename) {
		try {
			fs.rmSync(validate_file_name(filename))
		} catch (e) {}
	}
	let json2key_value = function (json) {
		let ret = "", temp;
		for (let i in json) {
			temp = json[i];
			if (temp instanceof Buffer) {
				let binary = false;
				for (let i of temp) {
					if (i > 127) {
						binary = true;
						break;
					}
				}
				if (binary) {
					temp = temp.toString("base64");
				} else {
					temp = temp.toString();
				}
			}
			if (typeof (temp) === "string" || typeof (temp) === "number" || (temp instanceof Number) || (temp instanceof String)) {
				temp = temp.toString();
			} else {
				try {
					temp = JSON.stringify(temp);
				} catch (e) {
					temp = temp.toString();
				}
			}
			ret += encodeURIComponent(i) + "=" + encodeURIComponent(temp) + "&";
		}
		return ret.slice(0, -1);
	};

	let login = async function (session, userName, password) {
		let response = await session("https://abook.hep.com.cn/loginMobile.action", { body: json2key_value({
			'device': 'iPhone',
			'loginUser.loginName': userName,
			'loginUser.loginPassword': crypto.createHash("md5").end(password).digest().toString("hex"),
			'packageId': 'com.hep.abook',
			'passType': 'MD5',
			'version': 'v1.170'
		}), headers: {
			"User-Agent": "iPhone",
			"Content-Type": "application/x-www-form-urlencoded"
		}, method: "post" });
		if (!response[0]) {
			return response[0];
		}
		response = JSON.parse(response[1]);
		if (response[0]["message"] == "successful") {
			return false;
		} else {
			return response[0]["message"];
		}
	};
	let fetchCourseList = async function (session) {
		let courseList = await session("https://abook.hep.com.cn/selectMyCourseList.action?mobile=true&cur=1");
		if (!courseList[0]) {
			try {
				return [false, JSON.parse(courseList[1])[0].myMobileCourseList];
			} catch (e) {
				return [e, undefined];
			}
		}
		return [courseList[0], undefined];
	};
	let parseResourceStrucure = function (courseResourceStrucure, courseInfoId) {
		let root = {
			haveMenu: false,
			name: "Course Resource Root",
			pId: -1,
			id: courseInfoId,
			type: -1,
		}, allResources = courseResourceStrucure, allResourcesById = {};
		allResources.push(root);
		for (let i of allResources) {
			i.children = [];
			i.childrenById = {};
			allResourcesById[i.id] = i;
			if (i.pId === 0) {
				i.pId = courseInfoId;
			}
		}
		for (let i of allResources) {
			if (i === root) {
				i.parent = null;
				continue;
			}
			allResourcesById[i.pId].children.push(i);
			// allResourcesById[i.pId].childrenById[i.id] = i;
			// i.parent = allResourcesById[i.pId];
		}
		allResourcesById[0] = root;
		return [root, allResources, allResourcesById];
	};
	let fetchResourceStrucure = async function (session, courseInfoId) {
		let courseResourceStrucure = await session("https://abook.hep.com.cn/resourceStructure.action?courseInfoId=%s".format(courseInfoId));
		if (!courseResourceStrucure[0]) {
			try {
				return [false, parseResourceStrucure(JSON.parse(courseResourceStrucure[1]), courseInfoId)];
			} catch (e) {
				return [e, undefined];
			}
		}
		return [courseResourceStrucure[0], undefined];
	};
	let getResourceInfo = async function (session, resourceInfoId) {
		let download_link_url = "https://abook.hep.com.cn/courseResourceList.action?courseInfoId={}&treeId={}&cur={}"
							.format(course_id, root_chapter['id'], cur)
		let download_url_base = "https://abook.hep.com.cn/ICourseFiles/"
		let download_link_url2 = "https://abook.hep.com.cn/selectResource.action?roleMenuId={}"
							.format(root_chapter['id'])
	};
	let downloadCourse = async function (session, courseInfoId, read = input, log = print) {
		let courseResourceStrucure;
		for (let i of range(5)) {
			courseResourceStrucure = await fetchResourceStrucure(session, courseInfoId);
			if (!courseResourceStrucure[0]) {
				courseResourceStrucure = courseResourceStrucure[1];
				log("Successfully fetched resourceStrucure of course %d.".format(courseInfoId));
				break;
			}
			if (i === 4) {
				log("Failed to fetched resourceStrucure of course %d.".format(courseInfoId));
				return courseResourceStrucure[0];
			}
			log("Failed to fetched resourceStrucure of course %d. Retry in 1 seconds.".format(courseInfoId));
			await sleep(1000);
		}
		print(courseResourceStrucure[0]);
	};

	(async function main() {
		let _session = request.defaults({
			jar: request.jar(),
			forever: true
		});
		let session = async function (url, options = {}) {
			let result = await promisify(_session, this, [url, options]);
			if (result[0]) {
				return [false, result[0]];
			}
			if (result[1].statusCode >= 400) {
				let error = new Error("HTTP(S) request error " + result[1].statusCode + ": " + result[1].statusMessage);
				error.statusMessage = result[1].statusMessage;
				error.statusCode = result[1].statusCode;
				error.response = result[1];
				error.body = result[2];
				return [error, undefined];
			}
			return [false, result[2]];
		};
		let config = {};
		while (true) {
			let userName = await input("Username: ");
			let password = await input("Password: ");
			userName = "Sam0230";
			password = "KKyz0yfnQS9XpGmZU+lX/A==";
			print("login()");
			if (!await login(session, userName, password)) {
				print("login() succeeded.");
				config.userName = userName;
				config.password = password;
				break;
			}
			print("login() failed.");
		}
									"https://abook.hep.com.cn/courseResourceList.action?courseInfoId=5000003478&treeId=5000360653&cur=1"
		// console.log(await session(	"https://abook.hep.com.cn/courseResourceList.action?courseInfoId=5000003478&treeId=5000360653&cur=1")); return;

		let courseList;
		let printCoursesList = function (courseList) {
			print("There are %d course(s) available: ".format(len(courseList)));
			for (let i in courseList) {
				print(i, courseList[i].courseInfoId, courseList[i].courseTitle);
			}
		};
		while (true) {
			while (true) {
				print("Fetching course list.");
				courseList = await fetchCourseList(session);
				if (courseList[0]) {
					print("Failed to fetched course list. Retry in 1 second.");
					await sleep(1000);
				} else {
					courseList = courseList[1];
					print("Successfully fetched course list.");
					break;
				}
			}
			printCoursesList(courseList);
			while (true) {
				let choice = (await input("Course number, or A to download all, R to reload, Q to quit: ")).toLowerCase();
				if (choice === "a") {
					for (let i of courseList) {
						await downloadCourse(session, i.courseInfoId);
					}
					printCoursesList(courseList);
					continue;
				}
				if (choice === "r") {
					break;
				}
				if (choice === "q") {
					return;
				}
				if (choice !== "" && !isNaN(choice) && choice < len(courseList)) {
					await downloadCourse(session, courseList[choice].courseInfoId);
					printCoursesList(courseList);
					continue;
				}
				print("Invalid input.");
			}
		}
	})();
})();
